import { Component } from "@angular/core";

@Component({
    selector: "template-form",
    templateUrl: "./Form.html"
})
export class FormExample {
    name!:string;

    onSubmit(value: any)
    {
        this.name=value.userName;
        console.log(value);
    }
}