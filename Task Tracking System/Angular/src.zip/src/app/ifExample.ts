import { componentFactoryName } from "@angular/compiler";
import {Component}from "@angular/core";

@Component({
    selector: "if-exam",
    templateUrl: "./if-example.html"
})

export class ifExample {
    age: number = 12;
}