export class MyService{
    getName(): string{
        return "abc";
    }

    getNumber(): number{
        return 10+20;
    }
}