import { Component } from "@angular/core";
import {MyService} from "./MyService";

@Component({
    selector: "my-com",
    template: `
    <div>
    <h1>Welcome to Sonata</h1>
     <h2> {{name}}</h2>
    </div>
    `,
    providers: [MyService]
})
export class MyComponent {
    name1: string;
    constructor(private sr: MyService) {
        this.name1=sr.getName();
    }
name: string = "Nikhil";

}