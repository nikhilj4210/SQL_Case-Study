export interface DeleteTaskInterface{
    taskID :number;
}