export class loginInterface{

    userID!:number;

    userName!:string;

    email!:string;

    fname!:string;

    lname!:string;

    phno!:bigint;

    role!:string;

    isactive!:boolean;

    dob!:Date;

    created_on!:Date;

    pwd!:string;

    }