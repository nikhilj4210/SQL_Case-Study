import {Component} from "@angular/core";

@Component({
    selector: "my-com1",
    template: `
    <div>
    <h1>Welcome to SDMIT</h1>
    <img src="./assets/SDMIT COLLEGE.jpeg">
    </div>
    `
})
export class MyComponent1{}