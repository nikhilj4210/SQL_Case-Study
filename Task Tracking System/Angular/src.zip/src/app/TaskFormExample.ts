import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'task-form',
  templateUrl: './TaskForm.html',
  
})
export class TaskFormExample implements OnInit {
  form:any
  taskid! : number;
  taskname! : string;
  description! : string;
  targetdate! : Date;
  status! : string;
  ownerid! : number;
  member! : string;
  priority! : string;


  constructor() { }

  ngOnInit() {
   this.form = new FormGroup(
     {
       TaskId : new FormControl(""), 
       TaskName : new FormControl(""),
       Description : new FormControl(""),
       TargetDate : new FormControl(""),
       Status : new FormControl(""),
       OwnerId : new FormControl(""),
       Member : new FormControl(""),
       Priority : new FormControl(""),
     }
   )}
     onSubmit(user:any)
     {
       console.log(user)
       this.taskid = user.TaskId;
       this.taskname = user.TaskName;
       this.description = user.Description;
       this.targetdate = user.TargetDate;
       this.status = user.Status;
       this.ownerid = user.OwnerId;
       this.member = user.Member;
       this.priority = user.Priority;
     }
}