import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddNotesComponent } from './add-notes/add-notes.component';
import { AssignTaskComponent } from './assign-task/assign-task.component';
import { BookmarkingComponent } from './bookmarking/bookmarking.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CaseStudy1Component } from './case-study1/case-study1.component';
import { SearchTaskComponent } from './search-task/search-task.component';
import { UpdatePriorityComponent } from './update-priority/update-priority.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { TrackStatusComponent } from './track-status/track-status.component';
import { DeleteTaskComponent} from './delete-task/delete-task.component'
import { LoginSuccessComponent } from './login-success/login-success.component';


const routes: Routes = [
  { path: '', component:UserLoginComponent},
  { path : 'GetTasks', component: CaseStudyComponent},
  { path : 'CreateTask', component: CaseStudy1Component},
  { path : 'AssignTask', component: AssignTaskComponent},
  { path : 'AddNotes', component: AddNotesComponent},
  { path : 'Bookmarking', component:BookmarkingComponent},
  { path : 'UpdatePriority', component:UpdatePriorityComponent},
  { path : 'SearchTask', component:SearchTaskComponent},
  {path : 'TrackStatus', component:TrackStatusComponent},
  {path:'DeleteTask', component:DeleteTaskComponent},
  {path: 'Home', component:LoginSuccessComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [UserLoginComponent,LoginSuccessComponent,CaseStudyComponent,CaseStudy1Component,AssignTaskComponent,AddNotesComponent,BookmarkingComponent,UpdatePriorityComponent,TrackStatusComponent,SearchTaskComponent,DeleteTaskComponent]