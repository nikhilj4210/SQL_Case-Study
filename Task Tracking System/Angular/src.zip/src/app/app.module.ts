import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from "@angular/forms";
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
/*import {MyComponent} from './MyComponent';
import {MyComponent1}from './MyComponent1';
import {ifExample} from './ifExample';
import {CustomDirective} from "./CustomDirective";
import { PipeExampleComponent } from './pipe-example/pipe-example.component';
import { CustomSortPipe } from './pipe-example/CustomSortPipe';
import { FormExample } from './FormExample';

import { ReactiveFormExample} from './ReactiveFormExample';
import { TaskFormExample} from './TaskFormExample';
import { EmployeeDetailsComponent } from './employee-details.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { PostExampleComponent } from './post-example/post-example.component';
import { MyModule } from 'src/MyModule';
import { FormValidation } from './FormValidation';
import { CaseStudy1Component } from './case-study1/case-study1.component';
import { UserLoginComponent } from './user-login/user-login.component';
import{AssignTaskComponent} from './assign-task/assign-task.component';
import { AddNotesComponent } from './add-notes/add-notes.component';
import { BookmarkingComponent } from './bookmarking/bookmarking.component';*/
import { routingComponents } from './app-routing.module';
//import { TrackStatusComponent } from './track-status/track-status.component';
//import { UpdatePriorityComponent } from './update-priority/update-priority.component';



@NgModule({
  declarations: [
    AppComponent,
    routingComponents
   
    
    
  
  ],
  imports: [
    BrowserModule, 
   
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }