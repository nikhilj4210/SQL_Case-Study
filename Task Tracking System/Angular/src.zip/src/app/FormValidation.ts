import { Component, OnInit } from "@angular/core";
import { FormGroup,FormControl,Validators, FormControlName } from "@angular/forms";
@Component({
    selector:"reactive",
    templateUrl:"./FormValidation.html"
})
export class FormValidation implements OnInit{
    form:any;
    firstname!:string;
    lastname!:string;
    ngOnInit(){
        this.form=new FormGroup({
            firstname:new FormControl("",Validators.compose([Validators.required, Validators.minLength(3)])),
            lastname:new FormControl("",Validators.compose([Validators.required, Validators.minLength(3)])),
            languages:new FormControl("")
        });
    }
    onSubmit(user: any)
    {
        console.log(user);
        this.firstname=user.firstname;
        
        this.lastname=user.lastname;
    }

}