import { NgModule} from "@angular/core";
import { SimpleComponent } from "./SimpleComponent";

@NgModule({
    declarations : [ SimpleComponent],
    imports : [],
    exports : [SimpleComponent]
})
export class MyModule{}