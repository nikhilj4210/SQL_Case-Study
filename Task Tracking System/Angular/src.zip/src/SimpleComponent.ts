import {Component} from "@angular/core";

@Component({
    selector: "one-com",
    template : `
    <div>
    <h1> This is my module component </h1>
    </div>
    `
})
export class SimpleComponent{}