import React from "react";


export default function MyCom(){
    return(
        <div>
            <h1> My Function Component</h1>
        </div>
    );
}