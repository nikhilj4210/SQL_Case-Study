import React, {Component} from "react";

import PropsExample1 from "./PropsExample1";

class ClassComponent1 extends Component{
    render(){
        return(
            <div>
                {this.props.studentid}
                {this.props.name}
                {this.props.marks}
            </div>
        );
    }
}

export default ClassComponent1;