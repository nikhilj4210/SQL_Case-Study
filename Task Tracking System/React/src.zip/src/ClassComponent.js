import React, {Component} from "react";

import PropsExample from "./PropsExample";

class ClassComponent extends Component{
    render(){
        return(
            <div>
                {this.props.name}
                {this.props.age}
            </div>
        );
    }
}

export default ClassComponent;