import React, { Component} from 'react';
import ClassComponent1 from './ClassComponent1';
import PropsExample1 from './PropsExample1';

class ClassComponentExample1 extends Component{
    render(){
        return(
            <div>

                <ClassComponent1 studentid= {121} name="Nikhil.J" marks={78}></ClassComponent1>
            </div>
        )
    }
}


export default ClassComponentExample1;