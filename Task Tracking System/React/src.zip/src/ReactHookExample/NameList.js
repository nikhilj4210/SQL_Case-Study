import React from "react";

function NameList(){
    const names =[ 'Nikhil', 'Sharath','Arsh']
    const nameList = names.map(name=><h1> {name} </h1>)

    const Product= [{ id:1, name:'TV',rate :567 },
    { id:2, name:'Mobile',rate :754 },
    { id:1, name:'Laptop',rate :674 }]

    const productList = Product.map(product => <h1> {product.id} {product.name}</h1>)
    return(
        <div>
            {nameList}
            {productList}
        </div>
    )
}

export default NameList;