import react from  'react';

const PropsExample1 = (props) => {
    return (
        <div>
            <h1> My Props example{props.studentid} {props.name} {props.marks}</h1>
            
        </div>
    )
}

export default PropsExample1;