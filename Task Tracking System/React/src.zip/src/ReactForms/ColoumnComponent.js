import React from 'react';
function ColoumnComponent (){
    return(
        <>
        <td> Name</td>
        <td> Nikhil</td>
        </>

    )
}
export default ColoumnComponent;