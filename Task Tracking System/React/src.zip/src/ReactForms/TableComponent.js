import React from 'react';
import ColoumnComponent from './ColoumnComponent';

function TableComponent(){
    return(
        <table border="1">
            <tbody>
                <tr>
                    <ColoumnComponent/>
                    <ColoumnComponent/>
                    <ColoumnComponent/>

                </tr>
            </tbody>
        </table>
    )
}
export default TableComponent;