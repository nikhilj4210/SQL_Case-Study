import React, {Component} from 'react';
import axios from 'axios';



class AddTask extends Component{
constructor(props){
super(props)
this.state={
taskID :'',
ownerID :'',
creatorID :'',
name : '',
description :'',
status :'',
priority :'',
notes :'',
isBookmarked : '',
createdOn :'',
statusChangedOn :''
}
this.changeHandler=this.changeHandler.bind(this);
this.submithandler=this.submithandler.bind(this);
}
changeHandler(e){
this.setState({[e.target.name]:e.target.value})
}
submithandler(e){
e.preventDefault()
console.log(this.state)
axios
.post('http://localhost:8080/createTask',this.state)
.then(response=>{
console.log(response)
})
.catch(error=>{
console.log(error)
})
}
render(){
const {taskID, ownerID,creatorID,name, description, status, priority, notes, isBookmarked, createdOn, statusChangedOn}=this.state
return(
    
<form style={{textAlign:"center", backgroundColor:'teal', fontFamily:'lucida grande'}}>  
<p style={{textAlign:"center", backgroundColor:'teal', fontFamily:'lucida grande'}}> <b> Enter The Details</b></p>
<div>
<form onSubmit={this.submithandler}>

<div>

<b>Task ___ID : </b>
<input type="number" name ="taskID" value ={taskID} onChange={this.changeHandler}/>

</div>
<br></br>

<div>
<b>Owner___ID: </b>
<input type="number" name ="ownerID" value ={ownerID} onChange={this.changeHandler}/>
</div>
<br></br>

<div>
<b>Creator_ID: </b>
<input type="number" name ="creatorID" value ={creatorID} onChange={this.changeHandler}/>
</div>
<br></br>

<div>
<b>Task Name :  </b>
<input type="text" name ="name" value ={name} onChange={this.changeHandler}/>
</div>
<br></br>

<div>
<b>Description: </b>
<input type="text" name ="description" value ={description} onChange={this.changeHandler}/>
</div>
<br></br>

<div>
<b>Status: </b>
<select id ="status" name="status" value ={status} onChange={this.changeHandler}>
<option value="select">select</option>
<option value ="InProgress">InProgress</option>
<option value ="OnHold">OnHold</option>
<option value ="Cancelled">Cancelled</option>
</select>
</div>
<br></br>

<div>
<b>Priority: </b>
<select id ="priority" name ="priority" value ={priority} onChange={this.changeHandler}>
<option value ="select">select</option>
<option value ="medium">medium</option>
<option value ="low">low</option>
<option value = "high">high</option>
</select>
</div>
<br></br>

<div>
<b>Add__Notes: </b>
<input type="text" name ="notes" value ={notes} onChange={this.changeHandler}/>
</div>
<br></br>

<div>
<b>isBookmarked: </b>
<select id ="isBookmarked" name ="isBookmarked" value ={isBookmarked} onChange={this.changeHandler}>

<option value ="false">false</option>
<option value = "true">true</option>
</select>
</div>
<br></br>

<div>
<b>Created__On: </b>
<input type="date" name ="createdOn" value ={createdOn} onChange={this.changeHandler}/>
</div>
<br></br>

<div>
<b>Status_Changed_On: </b>
<input type="date" name ="statusChangedOn" value ={statusChangedOn} onChange={this.changeHandler}/>
</div>
<br></br>




<button type="submit">Submit</button>
</form>
</div>
</form>

)
}



}
export default AddTask;