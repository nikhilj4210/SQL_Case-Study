import React from 'react';
//import ReactDOM from 'react-dom';
import {Route, Link, BrowserRouter as Router,Routes } from 'react-router-dom';
import App from '../App';
import GetTaskData from './GetTaskData';
import AddTask from './AddTask';
import UpdatePriority from './UpdatePriority';
import DeleteTask from './DeleteTask';

const routing=(
    <Router>
        <div>
        <div style={{"backgroundColor":"teal","color":"black", textAlign:"center"}}>

<h1 style={{fontFamily:'lucida grande', color: 'white'}}> <u> Welcome To Task Tracking System </u> </h1> 




            
               <form style={{"color":"black","textAlign":"center"}}>
                <ul>
                
                <li><button>
                    <Link to="/">Home</Link>
                </button> </li>
                </ul>
                <button>
                    <Link to="/gettask">Get all task</Link>
                </button>
                <button>
                    <Link to="/addtask">Create task </Link>
                </button>
                <button>
                    <Link to="/updatepri">Update Priority</Link>
                </button>
                <button>
                    <Link to="/delete">Delete Task</Link>
                </button>
               </form>
        
       
        <Routes>
            <Route path="/" element={<App/>} />
            <Route path="/gettask" element={<GetTaskData/>} />
            <Route path="/addtask" element={<AddTask/>} />
            <Route path="/updatepri" element={<UpdatePriority/>} />
            <Route path="/delete" element={<DeleteTask/>} />
          
          
           
        </Routes>
        </div>
        </div>
    </Router>
)
export default routing;