import React,{Component} from 'react';
import axios from 'axios';



class GetTaskData extends Component{
constructor(){
super()
this.state={
tasks:[]
}
this.handleClick = this.handleClick.bind(this)
}
handleClick(){
axios.get('http://localhost:8080/tasks')
.then(response => this.setState({tasks:response.data}))
}
render(){
return(
    <form style={{textAlign:"center", backgroundColor:'teal', fontFamily:'lucida grande'}}>
<div style={{ backgroundColor:'white', fontFamily:'lucida grande'}}>
<p  onClick={this.handleClick} style={{textAlign:"center", backgroundColor:'teal', fontFamily:'lucida grande', color:'teal'}}>List Of Tasks</p>

<ul style={{backgroundColor:'teal'}}>{this.state.tasks.map(task =>(<h3>
<li>TaskID:{task.taskID}</li>
<li>TaskName:{task.name}</li>
<li>TaskOwner:{task.ownerID}</li>
<li>Task CreatorID:{task.creatorID}</li>
<li>Task status:{task.status}</li>
<li>Description:{task.description}</li>
<li>notes:{task.notes}</li>
<li>statusChangedOn:{task.statusChangedOn}</li>
<li>Priority:{task.priority}</li>
<li>bookMarked:{task.isBookmarked.toString()}</li>
<li>createdon:{task.createdOn}</li>
<hr></hr>
</h3>))}

</ul>
<hr></hr>
</div>
</form>
)
}
}
export default GetTaskData;