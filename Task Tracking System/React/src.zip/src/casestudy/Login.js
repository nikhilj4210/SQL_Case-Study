import axios from "axios";
import React, { Component } from "react";
class UserLogin extends Component {
    constructor(props){
        super(props)
        this.state = {
            username:'',
            password:''
        }
        this.changeHandler=this.changeHandler.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
    }
    changeHandler = (event) => {
        this.setState({[event.target.name]:event.target.value})
    }
    submitHandler = (event) => {
        event.preventDefault()
        console.log(this.state)
        axios.get("http://localhost:8080/username/"+this.state.username+"/pwd/"+this.state.password,this.state)
        .then(response => {
            console.log(response)
            if((response.username="Nikhil")&&(response.password="niki123")){
                alert("Logged In Successfull!");
            }
            else{
                alert("Enter  Valid  Credentials.!")
            }
        })
        .catch(error => {
            console.log(error)
        })
    }
    render(){
        const {username,password} = this.state
        return (
            
            
            <div style={{"backgroundColor":"teal","color":"black", textAlign:"center"}}>

                <h1 style={{fontFamily:'lucida grande', color: 'white'}}>  Hello Admin....!!!  </h1> 
                <h3 style={{fontFamily:'lucida grande', color: 'white'}}>  Choose Your Task  </h3> 
                

            
        </div>
        
        
        )
    }
}
export default UserLogin;