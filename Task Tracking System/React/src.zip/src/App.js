import React from 'react'
import Login from './casestudy/Login'
import UpdatePriority from './casestudy/UpdatePriority'
//import GetTaskData from './casestudy/GetTaskData'
//import AddTask from './casestudy/AddTask'

function App(){
  return(
   
    <div>
  
  <Login> </Login>
    </div>
  )
}

export default App