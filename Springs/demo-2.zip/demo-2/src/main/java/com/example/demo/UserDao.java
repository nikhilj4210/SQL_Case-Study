package com.example.demo;

public interface UserDao {

	public int addUser(User user);
	
}
